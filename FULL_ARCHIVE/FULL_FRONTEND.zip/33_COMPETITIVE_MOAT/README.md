# 33 Competitive Moat

**Project:** FRONTEND
**Upstream:** https://github.com/home-assistant/frontend

Content specific to FRONTEND in category CONSUMER_APPLIANCES.
